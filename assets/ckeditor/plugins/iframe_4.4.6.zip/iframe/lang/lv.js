﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'lv', {
	border: 'Rādīt rāmi',
	noUrl: 'Norādiet iframe adresi',
	scrolling: 'Atļaut ritjoslas',
	title: 'IFrame uzstādījumi',
	toolbar: 'IFrame'
} );
